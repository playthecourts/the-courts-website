import { facilityNow } from "@/lib/facility-time";
import { getCurrentGuardian } from "@/lib/dal";
import { prisma } from "@/lib/prisma";
import { gradeRangeLabel } from "@/lib/programs/types";
import { effectiveEntitlements } from "@/lib/entitlements";
import { loadParentFeed } from "@/lib/programs/parent-feed";
import { expireStalePendingBookings } from "@/lib/booking";
import { startCampRegistration, cancelCampRegistration } from "./actions";
import { CampFilterBar } from "./filter-bar";
import { AchCallout } from "../ach-callout";
import { GroupedOfferingCard, type Card } from "../explore/offering-session-card";
import { CampTypeToggle } from "./type-toggle";

export const dynamic = "force-dynamic";

// Whole-camp registration (Fall Break, Thanksgiving, Winter Break — anything
// with registrationMode "offering" or "multi_day"). Single-day camps
// (Early Release, Day Off Game On) are registrationMode "session" and are
// booked through Explore instead, same as any other single session.

function formatCents(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

function formatDate(d: Date) {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", timeZone: "UTC" }).format(d);
}

function formatWeekday(d: Date) {
  return new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "UTC" }).format(d);
}

function formatMonth(d: Date) {
  return new Intl.DateTimeFormat("en-US", { month: "short", timeZone: "UTC" }).format(d);
}

// Each camp card gets a stable anchor from its name, so the website can link
// straight to it: /my-courts/camps#fall-break-volleyball-camp
function campAnchor(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export default async function CampsPage({
  searchParams,
}: {
  searchParams: Promise<{ checkout?: string }>;
}) {
  const guardian = await getCurrentGuardian();
  const sp = await searchParams;
  const athletes = guardian.families.flatMap((fg) => fg.family.athletes);
  const athleteIds = athletes.map((a) => a.id);

  // One-day events (Early Release, Day Off/Game On, Open Gym) — real
  // Offerings with registrationMode "session", booked the same way any
  // other class is (Explore's booking logic, untouched), just surfaced here
  // too now that this page is "Camps & Events" rather than only whole-camp
  // registration. A family that abandoned a Checkout for one of these needs
  // the same stale-hold sweep Explore runs before computing availability.
  await expireStalePendingBookings();
  const oneDayEventCards = await loadParentFeed(athletes as never, { category: "camps", from: facilityNow() });
  const oneDayEventGroups = (() => {
    const groups = new Map<string, Card[]>();
    for (const raw of oneDayEventCards) {
      const card = JSON.parse(JSON.stringify(raw)) as Card;
      const key = `${card.offeringId}-${card.startTime.slice(0, 10)}`;
      const existing = groups.get(key);
      if (existing) existing.push(card);
      else groups.set(key, [card]);
    }
    return [...groups.values()];
  })();

  const camps = await prisma.offering.findMany({
    where: {
      status: "published",
      internalOnly: false,
      visibleParentApp: true,
      registrationMode: { in: ["offering", "multi_day"] },
    },
    include: {
      sessions: { where: { status: "scheduled" }, orderBy: { startTime: "asc" } },
      registrations: { where: { athleteId: { in: athleteIds } } },
    },
    orderBy: { sessions: { _count: "asc" } },
  });
  // Sort by first session date — Prisma can't order by a nested aggregate
  // field here, so it's done in memory on the small result set instead.
  camps.sort((a, b) => (a.sessions[0]?.startTime.getTime() ?? 0) - (b.sessions[0]?.startTime.getTime() ?? 0));

  // Same member_pricing/class_credit entitlement check the checkout action
  // charges against (see hasMemberPricing in ./actions) — computed once per
  // athlete here so the price shown matches what they'd actually pay,
  // instead of always showing the flat non-member rate.
  const memberships = await prisma.athleteMembership.findMany({
    where: { athleteId: { in: athleteIds }, status: "active" },
    include: { plan: { include: { entitlements: true, entitlementsFromPlan: { include: { entitlements: true } } } } },
  });
  function isMemberFor(athleteId: string, programId: string) {
    return memberships.some(
      (m) =>
        m.athleteId === athleteId &&
        effectiveEntitlements(m.plan).some(
          (e) => (e.benefitType === "member_pricing" || e.benefitType === "class_credit") && (e.programId === null || e.programId === programId)
        )
    );
  }

  const singleDayContent = oneDayEventGroups.length > 0 && (
    <div className="flex flex-col gap-3">
      <p className="font-sport text-xs font-bold uppercase tracking-widest text-gray-dark">One-Day Events</p>
      {oneDayEventGroups.map((group) => (
        <div key={`${group[0].offeringId}-${group[0].sessionId}`} id={campAnchor(group[0].offeringName)} className="scroll-mt-24">
          <GroupedOfferingCard cards={group} />
        </div>
      ))}
    </div>
  );

  const multiDayContent =
    athletes.length === 0 ? (
      <div className="rounded-xl border border-gray-mid bg-white p-6 text-center">
        <p className="font-body text-sm text-gray-dark">Add an athlete to your family before registering for a camp.</p>
      </div>
    ) : (
      (() => {
        const months = [
          ...new Set(camps.map((c) => (c.sessions[0] ? formatMonth(c.sessions[0].startTime) : null)).filter((m): m is string => Boolean(m))),
        ];
        const items = camps.map((camp) => {
          const first = camp.sessions[0];
          const last = camp.sessions[camp.sessions.length - 1];
          const dateLabel =
            first && last && first.id !== last.id
              ? `${formatWeekday(first.startTime)}–${formatWeekday(last.startTime)}, ${formatDate(first.startTime)}–${formatDate(last.startTime)}`
              : first
                ? `${formatWeekday(first.startTime)}, ${formatDate(first.startTime)}`
                : "Dates TBD";
          const gradeLabel = gradeRangeLabel(camp.gradeMin, camp.gradeMax);
          const sport = /volleyball/i.test(camp.name) ? "volleyball" : /basketball/i.test(camp.name) ? "basketball" : "other";
          const month = first ? formatMonth(first.startTime) : "other";

          const node = (
            <div id={campAnchor(camp.name)} className="scroll-mt-24 overflow-hidden rounded-xl border border-gray-mid bg-white">
              <div className="border-b border-gray-mid bg-warm-stone px-4 py-3">
                {sport !== "other" && (
                  <p className="font-sport text-xs font-bold uppercase tracking-wide text-orange">
                    {sport === "volleyball" ? "Volleyball" : "Basketball"}
                  </p>
                )}
                <p className="font-sport text-base font-bold text-black">{dateLabel}</p>
                <h2 className="font-display text-lg font-black text-black">{camp.name}</h2>
                <p className="mt-0.5 font-body text-sm text-gray-dark">
                  {formatCents(camp.priceCents ?? 0)}
                  {camp.memberPriceCents != null ? ` · Members ${formatCents(camp.memberPriceCents)}` : ""}
                  {camp.registrationMode === "multi_day" && camp.allowSingleDay && camp.singleDayPriceCents
                    ? ` full week · ${formatCents(camp.singleDayPriceCents)}/day`
                    : ""}
                  {gradeLabel ? ` · ${gradeLabel}` : ""}
                </p>
              </div>

              <ul className="divide-y divide-gray-mid">
                {athletes.map((athlete) => {
                  const reg = camp.registrations.find((r) => r.athleteId === athlete.id);
                  const paid = reg?.paymentStatus === "paid";
                  const pending = reg && reg.status !== "cancelled" && !paid;
                  const isMember = isMemberFor(athlete.id, camp.programId);
                  const fullWeekPrice = isMember && camp.memberPriceCents != null ? camp.memberPriceCents : camp.priceCents ?? 0;
                  const singleDayPrice =
                    isMember && camp.singleDayMemberPriceCents != null
                      ? camp.singleDayMemberPriceCents
                      : (camp.singleDayPriceCents ?? camp.priceCents ?? 0);

                  return (
                    <li key={athlete.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3.5">
                      <span className="font-body text-sm font-medium text-near-black">
                        {athlete.firstName}
                        <span className={`ml-2 text-xs font-bold uppercase tracking-wide ${isMember ? "text-orange" : "text-gray-dark"}`}>
                          {isMember ? "Member" : "Non-Member"}
                        </span>
                        {pending && (
                          <span className="ml-2 inline-flex items-center justify-center rounded-full bg-orange/10 px-2.5 py-1 font-sport text-[11.5px] font-bold uppercase tracking-wide text-orange">
                            Payment Pending
                          </span>
                        )}
                      </span>

                      {paid ? (
                        <span className="rounded-full bg-green-50 px-3 py-1 font-sport text-xs font-bold uppercase tracking-wide text-green-800">
                          Registered — {reg?.selection === "single_day" ? "1 Day" : "Full Camp"}
                        </span>
                      ) : (
                        <div className="flex flex-wrap items-center gap-2">
                          {pending && (
                            <form action={cancelCampRegistration}>
                              <input type="hidden" name="athleteId" value={athlete.id} />
                              <input type="hidden" name="offeringId" value={camp.id} />
                              <button className="font-sport text-xs font-bold uppercase tracking-wide text-gray-dark hover:text-danger">
                                Cancel
                              </button>
                            </form>
                          )}
                          <form action={startCampRegistration} className="flex items-center gap-2">
                            <input type="hidden" name="athleteId" value={athlete.id} />
                            <input type="hidden" name="offeringId" value={camp.id} />
                            {camp.registrationMode === "multi_day" && camp.allowSingleDay ? (
                              <select
                                name="dayChoice"
                                defaultValue="full"
                                className="min-h-9 rounded-lg border border-gray-mid bg-white px-2 text-xs"
                              >
                                <option value="full">Full — {formatCents(fullWeekPrice)}</option>
                                {camp.sessions.map((s) => (
                                  <option key={s.id} value={s.id}>
                                    {formatWeekday(s.startTime)}, {formatDate(s.startTime)} — {formatCents(singleDayPrice)}
                                  </option>
                                ))}
                              </select>
                            ) : null}
                            <button className="rounded-full bg-orange px-4 py-2 font-heading text-xs font-bold uppercase tracking-wide text-white hover:bg-orange-hover">
                              Register{camp.registrationMode === "offering" ? ` — ${formatCents(fullWeekPrice)}` : ""}
                            </button>
                          </form>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>

              <p className="border-t border-gray-mid px-4 py-2.5 font-body text-[12.5px] text-gray-dark">
                No refunds after registration.
              </p>
            </div>
          );

          return { id: camp.id, sport, month, node } as const;
        });

        return (
          <div className="flex flex-col gap-3">
            {camps.length > 0 && oneDayEventGroups.length > 0 && (
              <p className="font-sport text-xs font-bold uppercase tracking-widest text-gray-dark">Multi-Day Camps</p>
            )}
            <CampFilterBar items={items} months={months} />
          </div>
        );
      })()
    );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="font-sport text-xs font-bold uppercase tracking-wide text-orange">Book</p>
        <h1 className="font-display text-3xl font-black text-black sm:text-4xl">Camps &amp; Events</h1>
      </div>

      {sp.checkout === "success" && (
        <div className="rounded-xl border border-green-600/30 bg-green-50 px-4 py-3 text-sm text-green-800">
          Registered! We&rsquo;ll see you there.
        </div>
      )}
      {sp.checkout === "error" && (
        <div className="rounded-xl border border-danger/30 bg-danger-bg px-4 py-3 text-sm text-danger">
          Something went wrong starting checkout. Try again, or contact us if it keeps happening.
        </div>
      )}

      <AchCallout />

      {/* The toggle only earns its place when there's actually something on
          both sides to switch between — one athlete-less family, or a slow
          camps month with only one type live, just sees that section, same
          as before this toggle existed. */}
      {oneDayEventGroups.length > 0 && camps.length > 0 ? (
        <CampTypeToggle singleDay={singleDayContent} multiDay={multiDayContent} />
      ) : (
        <>
          {singleDayContent}
          {multiDayContent}
        </>
      )}

      {camps.length === 0 && athletes.length > 0 && (
        <div className="rounded-xl border border-gray-mid bg-white p-6 text-center">
          <p className="font-body text-sm text-gray-dark">No camps open for registration right now.</p>
        </div>
      )}
    </div>
  );
}
